from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt


def plot_label_distribution(y):
    y.value_counts().plot(kind="bar")
    plt.title("Loneliness Label Distribution")
    plt.xlabel("Label")
    plt.ylabel("Count")
    plt.show()


def plot_feature_importance(top_features_path):
    df = pd.read_csv(top_features_path)

    df = df.sort_values(by="abs_coef", ascending=True)

    plt.figure(figsize=(8, 6))
    plt.barh(df["feature"], df["abs_coef"])
    plt.title("Top Features Influencing Loneliness")
    plt.xlabel("Importance (Absolute Coefficient)")
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    current_file = Path(__file__).resolve()
    project_root = current_file.parents[2]

    y_path = project_root / "data" / "processed" / "y.csv"
    top_features_path = project_root / "outputs" / "reports" / "top_features.csv"

    y = pd.read_csv(y_path).squeeze("columns")

    plot_label_distribution(y)
    plot_feature_importance(top_features_path)