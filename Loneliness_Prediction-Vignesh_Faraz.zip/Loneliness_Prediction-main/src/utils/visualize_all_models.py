from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import StratifiedKFold, cross_val_predict, cross_validate
from sklearn.pipeline import Pipeline
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier

from sklearn.metrics import (
    confusion_matrix,
    ConfusionMatrixDisplay,
    RocCurveDisplay,
    PrecisionRecallDisplay,
    precision_recall_curve,
    roc_curve,
    auc,
)


def load_data(x_path, y_path):
    X = pd.read_csv(x_path)
    y = pd.read_csv(y_path).squeeze("columns")
    return X, y


def get_models():
    return {
        "Logistic Regression + SelectKBest": Pipeline([
            ("feature_selection", SelectKBest(score_func=f_classif, k=15)),
            ("model", LogisticRegression(max_iter=1000, random_state=42))
        ]),
        "SVM + SelectKBest": Pipeline([
            ("feature_selection", SelectKBest(score_func=f_classif, k=15)),
            ("model", SVC(kernel="linear", probability=True, random_state=42))
        ]),
        "Random Forest": RandomForestClassifier(
            n_estimators=100,
            max_depth=5,
            random_state=42
        ),
        "XGBoost + SelectKBest": Pipeline([
            ("feature_selection", SelectKBest(score_func=f_classif, k=15)),
            ("model", XGBClassifier(
                n_estimators=50,
                max_depth=3,
                learning_rate=0.05,
                subsample=0.8,
                colsample_bytree=0.8,
                eval_metric="logloss",
                random_state=42
            ))
        ]),
    }


def get_cv():
    return StratifiedKFold(n_splits=5, shuffle=True, random_state=42)


def evaluate_and_collect(model, X, y, cv):
    scoring = {
        "accuracy": "accuracy",
        "precision": "precision",
        "recall": "recall",
        "f1": "f1",
        "roc_auc": "roc_auc",
    }

    cv_results = cross_validate(model, X, y, cv=cv, scoring=scoring)

    y_pred = cross_val_predict(model, X, y, cv=cv, method="predict")

    if hasattr(model, "predict_proba"):
        y_score = cross_val_predict(model, X, y, cv=cv, method="predict_proba")[:, 1]
    else:
        y_score = cross_val_predict(model, X, y, cv=cv, method="decision_function")

    metrics = {
        "Accuracy": np.mean(cv_results["test_accuracy"]),
        "Precision": np.mean(cv_results["test_precision"]),
        "Recall": np.mean(cv_results["test_recall"]),
        "F1 Score": np.mean(cv_results["test_f1"]),
        "ROC-AUC": np.mean(cv_results["test_roc_auc"]),
    }

    return metrics, y_pred, y_score


def plot_confusion_matrix_all(results_dict, y_true, output_dir):
    for model_name, result in results_dict.items():
        cm = confusion_matrix(y_true, result["y_pred"])
        disp = ConfusionMatrixDisplay(confusion_matrix=cm)
        disp.plot()
        plt.title(f"Confusion Matrix - {model_name}")
        plt.tight_layout()
        filename = model_name.lower().replace(" ", "_").replace("+", "plus")
        plt.savefig(output_dir / f"{filename}_confusion_matrix.png", dpi=300, bbox_inches="tight")
        plt.show()
        plt.close()


def plot_roc_curves(results_dict, y_true, output_dir):
    plt.figure(figsize=(8, 6))

    for model_name, result in results_dict.items():
        fpr, tpr, _ = roc_curve(y_true, result["y_score"])
        roc_auc_value = auc(fpr, tpr)
        plt.plot(fpr, tpr, label=f"{model_name} (AUC = {roc_auc_value:.3f})")

    plt.plot([0, 1], [0, 1], linestyle="--")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC Curves - All Models")
    plt.legend()
    plt.tight_layout()
    plt.savefig(output_dir / "all_models_roc_curve.png", dpi=300, bbox_inches="tight")
    plt.show()
    plt.close()


def plot_precision_recall_curves(results_dict, y_true, output_dir):
    plt.figure(figsize=(8, 6))

    for model_name, result in results_dict.items():
        precision, recall, _ = precision_recall_curve(y_true, result["y_score"])
        pr_auc_value = auc(recall, precision)
        plt.plot(recall, precision, label=f"{model_name} (AUC = {pr_auc_value:.3f})")

    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.title("Precision-Recall Curves - All Models")
    plt.legend()
    plt.tight_layout()
    plt.savefig(output_dir / "all_models_precision_recall_curve.png", dpi=300, bbox_inches="tight")
    plt.show()
    plt.close()


def plot_metric_comparison(metrics_df, output_dir):
    metric_names = ["Accuracy", "Precision", "Recall", "F1 Score", "ROC-AUC"]

    for metric in metric_names:
        plt.figure(figsize=(8, 5))
        plt.bar(metrics_df["Model"], metrics_df[metric])
        plt.xticks(rotation=20, ha="right")
        plt.ylabel(metric)
        plt.title(f"{metric} Comparison Across Models")
        plt.tight_layout()

        safe_metric = metric.lower().replace(" ", "_").replace("-", "_")
        plt.savefig(output_dir / f"{safe_metric}_comparison.png", dpi=300, bbox_inches="tight")
        plt.show()
        plt.close()


def plot_all_metrics_grouped(metrics_df, output_dir):
    metrics_only = metrics_df.set_index("Model")
    ax = metrics_only.plot(kind="bar", figsize=(10, 6))
    ax.set_title("All Metrics Comparison Across Models")
    ax.set_ylabel("Score")
    ax.set_xlabel("Model")
    plt.xticks(rotation=20, ha="right")
    plt.tight_layout()
    plt.savefig(output_dir / "all_metrics_grouped.png", dpi=300, bbox_inches="tight")
    plt.show()
    plt.close()


def plot_feature_importance_for_tree_models(models, X, y, output_dir):
    tree_model_names = ["Random Forest", "XGBoost + SelectKBest"]

    for model_name in tree_model_names:
        model = models[model_name]
        model.fit(X, y)

        if isinstance(model, Pipeline):
            selector = model.named_steps["feature_selection"]
            selected_mask = selector.get_support()
            selected_features = X.columns[selected_mask]

            tree_part = model.named_steps["model"]
            importances = tree_part.feature_importances_
            feature_names = selected_features
        else:
            importances = model.feature_importances_
            feature_names = X.columns

        importance_df = pd.DataFrame({
            "feature": feature_names,
            "importance": importances
        }).sort_values(by="importance", ascending=False).head(15)

        plt.figure(figsize=(8, 6))
        plt.barh(importance_df["feature"][::-1], importance_df["importance"][::-1])
        plt.title(f"Top 15 Feature Importances - {model_name}")
        plt.xlabel("Importance")
        plt.tight_layout()

        filename = model_name.lower().replace(" ", "_").replace("+", "plus")
        plt.savefig(output_dir / f"{filename}_feature_importance.png", dpi=300, bbox_inches="tight")
        plt.show()
        plt.close()


def main():
    current_file = Path(__file__).resolve()
    project_root = current_file.parents[2]

    x_path = project_root / "data" / "processed" / "X.csv"
    y_path = project_root / "data" / "processed" / "y.csv"
    output_dir = project_root / "outputs" / "figures"
    output_dir.mkdir(parents=True, exist_ok=True)

    X, y = load_data(x_path, y_path)
    models = get_models()
    cv = get_cv()

    all_results = []

    results_dict = {}

    for model_name, model in models.items():
        print(f"Processing {model_name} ...")
        metrics, y_pred, y_score = evaluate_and_collect(model, X, y, cv)

        row = {"Model": model_name}
        row.update(metrics)
        all_results.append(row)

        results_dict[model_name] = {
            "metrics": metrics,
            "y_pred": y_pred,
            "y_score": y_score
        }

    metrics_df = pd.DataFrame(all_results)
    print("\nModel comparison table:")
    print(metrics_df)

    metrics_df.to_csv(project_root / "outputs" / "reports" / "model_comparison_visuals.csv", index=False)

    plot_confusion_matrix_all(results_dict, y, output_dir)
    plot_roc_curves(results_dict, y, output_dir)
    plot_precision_recall_curves(results_dict, y, output_dir)
    plot_metric_comparison(metrics_df, output_dir)
    plot_all_metrics_grouped(metrics_df, output_dir)
    plot_feature_importance_for_tree_models(models, X, y, output_dir)

    print(f"\nAll visualizations saved in: {output_dir}")


if __name__ == "__main__":
    main()