from pathlib import Path
import pandas as pd

from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline


def load_data(x_path, y_path):
    """
    Load X and y.
    """
    X = pd.read_csv(x_path)
    y = pd.read_csv(y_path).squeeze("columns")
    return X, y


def build_pipeline(k=15):
    """
    Same pipeline as baseline model:
    1. Select top-k features
    2. Train logistic regression
    """
    pipeline = Pipeline([
        ("feature_selection", SelectKBest(score_func=f_classif, k=k)),
        ("model", LogisticRegression(max_iter=1000, random_state=42))
    ])
    return pipeline


def show_top_features(X, y, k=15):
    """
    Fit pipeline on all data and show:
    - selected features
    - ANOVA scores
    - logistic regression coefficients
    """
    pipeline = build_pipeline(k=k)
    pipeline.fit(X, y)

    selector = pipeline.named_steps["feature_selection"]
    model = pipeline.named_steps["model"]

    selected_mask = selector.get_support()
    selected_features = X.columns[selected_mask]

    selected_scores = selector.scores_[selected_mask]
    selected_coefs = model.coef_[0]

    results = pd.DataFrame({
        "feature": selected_features,
        "anova_score": selected_scores,
        "logistic_coef": selected_coefs,
        "abs_coef": abs(selected_coefs)
    })

    results = results.sort_values(by="abs_coef", ascending=False).reset_index(drop=True)

    print(f"Top {k} selected features:\n")
    print(results)

    return results


if __name__ == "__main__":
    current_file = Path(__file__).resolve()
    project_root = current_file.parents[2]

    x_path = project_root / "data" / "processed" / "X.csv"
    y_path = project_root / "data" / "processed" / "y.csv"
    output_path = project_root / "outputs" / "reports" / "top_features.csv"

    X, y = load_data(x_path, y_path)

    results = show_top_features(X, y, k=15)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    results.to_csv(output_path, index=False)

    print(f"\nSaved to: {output_path}")