from pathlib import Path
import pandas as pd

from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.pipeline import Pipeline


def load_data(x_path, y_path):
    X = pd.read_csv(x_path)
    y = pd.read_csv(y_path).squeeze("columns")
    return X, y


def build_pipeline(n_components=10):
    pipeline = Pipeline([
        ("pca", PCA(n_components=n_components)),
        ("model", LogisticRegression(max_iter=1000, random_state=42))
    ])
    return pipeline


def evaluate_model(X, y, n_components=10):
    pipeline = build_pipeline(n_components=n_components)

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

    accuracy = cross_val_score(pipeline, X, y, cv=cv, scoring="accuracy")
    f1 = cross_val_score(pipeline, X, y, cv=cv, scoring="f1")

    print(f"PCA components: {n_components}")
    print("\nAccuracy scores:", accuracy)
    print("Mean accuracy:", accuracy.mean())

    print("\nF1 scores:", f1)
    print("Mean F1:", f1.mean())


if __name__ == "__main__":
    current_file = Path(__file__).resolve()
    project_root = current_file.parents[2]

    x_path = project_root / "data" / "processed" / "X.csv"
    y_path = project_root / "data" / "processed" / "y.csv"

    X, y = load_data(x_path, y_path)

    evaluate_model(X, y, n_components=10)