from pathlib import Path
import pandas as pd

from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.pipeline import Pipeline
from xgboost import XGBClassifier


def load_data(x_path, y_path):
    X = pd.read_csv(x_path)
    y = pd.read_csv(y_path).squeeze("columns")
    return X, y


def evaluate_model(X, y, k=15):
    model = Pipeline([
        ("feature_selection", SelectKBest(score_func=f_classif, k=k)),
        ("xgb", XGBClassifier(
            n_estimators=50,
            max_depth=3,
            learning_rate=0.05,
            subsample=0.8,
            colsample_bytree=0.8,
            eval_metric="logloss",
            random_state=42
        ))
    ])

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

    accuracy = cross_val_score(model, X, y, cv=cv, scoring="accuracy")
    f1 = cross_val_score(model, X, y, cv=cv, scoring="f1")

    print("\nXGBoost Results\n")
    print("Accuracy scores:", accuracy)
    print("Mean accuracy:", accuracy.mean())

    print("\nF1 scores:", f1)
    print("Mean F1:", f1.mean())


if __name__ == "__main__":
    current_file = Path(__file__).resolve()
    project_root = current_file.parents[2]

    x_path = project_root / "data" / "processed" / "X.csv"
    y_path = project_root / "data" / "processed" / "y.csv"

    X, y = load_data(x_path, y_path)
    evaluate_model(X, y, k=15)