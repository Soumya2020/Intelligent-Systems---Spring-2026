# Imports basic libraries
import pandas as pd
import numpy as np

# Imports train-test split
from sklearn.model_selection import train_test_split

# Imports feature scaler
from sklearn.preprocessing import StandardScaler

# Imports MLP classifier
from sklearn.neural_network import MLPClassifier

# Imports evaluation metrics
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
    classification_report
)

# -------------------------------
# 1. Load selected features and target
# -------------------------------
X_path = r"F:\PythonProject\prjoect4lonely\data\processed\X.csv"
y_path = r"F:\PythonProject\prjoect4lonely\data\processed\y.csv"

X = pd.read_csv(X_path)
y_df = pd.read_csv(y_path)

print("X shape:", X.shape)
print("y shape:", y_df.shape)

# Convert y to 1D
if y_df.shape[1] == 1:
    y = y_df.iloc[:, 0]
else:
    y = y_df["loneliness_label"]

# -------------------------------
# 2. Train-test split
# -------------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

print("\nTrain shape:", X_train.shape)
print("Test shape:", X_test.shape)

# -------------------------------
# 3. Scale features (VERY IMPORTANT for NN)
# -------------------------------
scaler = StandardScaler()

X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# -------------------------------
# 4. Build Neural Network
# -------------------------------
mlp_model = MLPClassifier(
    hidden_layer_sizes=(16, 8),   # small network works best here
    activation='relu',
    solver='adam',
    alpha=0.001,                 # regularization (important)
    learning_rate='adaptive',
    learning_rate_init=0.001,
    max_iter=1000,
    random_state=42,
    early_stopping=True,
    validation_fraction=0.1,
    n_iter_no_change=20
)

# Train model
mlp_model.fit(X_train_scaled, y_train)

# -------------------------------
# 5. Predictions
# -------------------------------
y_pred = mlp_model.predict(X_test_scaled)
y_prob = mlp_model.predict_proba(X_test_scaled)[:, 1]

# -------------------------------
# 6. Evaluation
# -------------------------------
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred, zero_division=0)
recall = recall_score(y_test, y_pred, zero_division=0)
f1 = f1_score(y_test, y_pred, zero_division=0)
roc_auc = roc_auc_score(y_test, y_prob)

print("\nMLP Neural Network Results (Best Version)")
print("-" * 45)
print(f"Accuracy:  {accuracy:.3f}")
print(f"Precision: {precision:.3f}")
print(f"Recall:    {recall:.3f}")
print(f"F1 Score:  {f1:.3f}")
print(f"ROC-AUC:   {roc_auc:.3f}")

print("\nConfusion Matrix")
print(confusion_matrix(y_test, y_pred))

print("\nClassification Report")
print(classification_report(y_test, y_pred, zero_division=0))