from pathlib import Path
import pandas as pd

from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.pipeline import Pipeline


def load_data(x_path, y_path):
    """
    Load feature matrix X and target y.
    """
    X = pd.read_csv(x_path)
    y = pd.read_csv(y_path).squeeze("columns")
    return X, y


def build_pipeline(k=15):
    """
    Build a simple baseline pipeline:
    1. Select top-k features
    2. Train logistic regression
    """
    pipeline = Pipeline([
        ("feature_selection", SelectKBest(score_func=f_classif, k=k)),
        ("model", LogisticRegression(max_iter=1000, random_state=42))
    ])
    return pipeline


def evaluate_model(X, y, k=15):
    """
    Evaluate the model using stratified cross-validation.
    """
    pipeline = build_pipeline(k=k)

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

    accuracy_scores = cross_val_score(
        pipeline, X, y, cv=cv, scoring="accuracy"
    )

    f1_scores = cross_val_score(
        pipeline, X, y, cv=cv, scoring="f1"
    )

    print(f"Number of samples: {len(X)}")
    print(f"Number of features before selection: {X.shape[1]}")
    print(f"Top-k selected features: {k}\n")

    print("Cross-validation accuracy scores:", accuracy_scores)
    print("Mean accuracy:", accuracy_scores.mean())

    print("\nCross-validation F1 scores:", f1_scores)
    print("Mean F1:", f1_scores.mean())


if __name__ == "__main__":
    current_file = Path(__file__).resolve()
    project_root = current_file.parents[2]

    x_path = project_root / "data" / "processed" / "X.csv"
    y_path = project_root / "data" / "processed" / "y.csv"

    X, y = load_data(x_path, y_path)

    evaluate_model(X, y, k=15)