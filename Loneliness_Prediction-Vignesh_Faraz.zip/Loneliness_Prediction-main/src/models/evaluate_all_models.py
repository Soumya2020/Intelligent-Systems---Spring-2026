from pathlib import Path
import pandas as pd
import numpy as np

from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
)
from sklearn.pipeline import Pipeline
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier


def load_data(x_path, y_path):
    X = pd.read_csv(x_path)
    y = pd.read_csv(y_path).squeeze("columns")
    return X, y


def evaluate_model(model, X, y, name):
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

    acc_list, prec_list, rec_list, f1_list, roc_list = [], [], [], [], []

    for train_idx, test_idx in cv.split(X, y):
        X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
        y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]

        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)

        if hasattr(model, "predict_proba"):
            y_score = model.predict_proba(X_test)[:, 1]
        else:
            y_score = model.decision_function(X_test)

        acc_list.append(accuracy_score(y_test, y_pred))
        prec_list.append(precision_score(y_test, y_pred, zero_division=0))
        rec_list.append(recall_score(y_test, y_pred, zero_division=0))
        f1_list.append(f1_score(y_test, y_pred, zero_division=0))
        roc_list.append(roc_auc_score(y_test, y_score))

    results = {
        "Model": name,
        "Accuracy": np.mean(acc_list),
        "Precision": np.mean(prec_list),
        "Recall": np.mean(rec_list),
        "F1 Score": np.mean(f1_list),
        "ROC-AUC": np.mean(roc_list),
    }

    print(f"\n{name} Results")
    print("-" * 30)
    print(f"Accuracy:  {results['Accuracy']:.3f}")
    print(f"Precision: {results['Precision']:.3f}")
    print(f"Recall:    {results['Recall']:.3f}")
    print(f"F1 Score:  {results['F1 Score']:.3f}")
    print(f"ROC-AUC:   {results['ROC-AUC']:.3f}")

    return results


if __name__ == "__main__":
    current_file = Path(__file__).resolve()
    project_root = current_file.parents[2]

    x_path = project_root / "data" / "processed" / "X.csv"
    y_path = project_root / "data" / "processed" / "y.csv"
    output_path = project_root / "outputs" / "reports" / "model_comparison.csv"

    X, y = load_data(x_path, y_path)

    models = {
        "Logistic Regression + SelectKBest": Pipeline([
            ("feature_selection", SelectKBest(score_func=f_classif, k=15)),
            ("model", LogisticRegression(max_iter=1000, random_state=42))
        ]),
        "SVM + SelectKBest": Pipeline([
            ("feature_selection", SelectKBest(score_func=f_classif, k=15)),
            ("model", SVC(kernel="linear", probability=True, random_state=42))
        ]),
        "Random Forest": RandomForestClassifier(
            n_estimators=100,
            max_depth=5,
            random_state=42
        ),
        "XGBoost": Pipeline([
            ("feature_selection", SelectKBest(score_func=f_classif, k=15)),
            ("model", XGBClassifier(
                n_estimators=50,
                max_depth=3,
                learning_rate=0.05,
                subsample=0.8,
                colsample_bytree=0.8,
                eval_metric="logloss",
                random_state=42
            ))
        ]),
    }

    all_results = []

    for name, model in models.items():
        result = evaluate_model(model, X, y, name)
        all_results.append(result)

    results_df = pd.DataFrame(all_results)
    results_df.to_csv(output_path, index=False)

    print(f"\nSaved comparison table to: {output_path}")