from pathlib import Path
import pandas as pd


def merge_datasets(aware_path, ucla_path):
    # Load datasets
    aware_df = pd.read_csv(aware_path)
    ucla_df = pd.read_csv(ucla_path)

    print("Aware shape:", aware_df.shape)
    print("UCLA shape:", ucla_df.shape)

    # Merge using INNER JOIN
    merged_df = aware_df.merge(ucla_df, on="participant", how="inner")

    print("\nMerged shape:", merged_df.shape)

    # Check label distribution
    print("\nLabel distribution:")
    print(merged_df["loneliness_label"].value_counts())

    return merged_df


if __name__ == "__main__":
    current_file = Path(__file__).resolve()
    project_root = current_file.parents[2]

    aware_path = project_root / "data" / "processed" / "aware_features_clean.csv"
    ucla_path = project_root / "data" / "processed" / "ucla_targets.csv"
    output_path = project_root / "data" / "processed" / "final_dataset.csv"

    final_df = merge_datasets(aware_path, ucla_path)

    print("\nPreview:")
    print(final_df.head())

    final_df.to_csv(output_path, index=False)

    print(f"\nSaved to: {output_path}")