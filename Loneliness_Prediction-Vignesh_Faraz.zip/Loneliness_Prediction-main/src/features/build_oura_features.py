from pathlib import Path
import pandas as pd
import numpy as np


def get_participant_paths(base_path):
    return sorted([p for p in base_path.iterdir() if p.is_dir()])


def load_oura_file(participant_path):
    oura_path = participant_path / "Oura"

    if not oura_path.exists():
        return None

    for file in oura_path.glob("*.csv"):
        return pd.read_csv(file)

    return None


def clean_oura_df(df):
    df = df.copy()

    # Convert everything except participant to numeric
    for col in df.columns:
        if col != "participant":
            df[col] = pd.to_numeric(df[col], errors="coerce")

    return df


def extract_oura_features(df):
    features = {}

    if df is None or df.empty:
        return features

    df = clean_oura_df(df)

    numeric_cols = df.select_dtypes(include=[np.number]).columns

    for col in numeric_cols:
        if col == "timestamp":
            continue

        features[f"{col}_mean"] = df[col].mean()
        features[f"{col}_std"] = df[col].std()
        features[f"{col}_min"] = df[col].min()
        features[f"{col}_max"] = df[col].max()

    return features


def build_oura_features_for_participant(participant_path):
    df = load_oura_file(participant_path)

    row = {"participant": participant_path.name}

    if df is None:
        return row

    features = extract_oura_features(df)
    row.update(features)

    return row


def build_oura_dataset(base_path):
    participant_folders = get_participant_paths(base_path)

    rows = []

    for participant_path in participant_folders:
        rows.append(build_oura_features_for_participant(participant_path))

    return pd.DataFrame(rows)


if __name__ == "__main__":
    current_file = Path(__file__).resolve()
    project_root = current_file.parents[2]

    base_path = project_root / "data" / "raw" / "Loneliness_Dataset_Nov10"
    output_path = project_root / "data" / "processed" / "oura_features.csv"

    print("Building Oura features...\n")

    oura_df = build_oura_dataset(base_path)

    print("Shape:", oura_df.shape)
    print("\nPreview:")
    print(oura_df.head())

    oura_df.to_csv(output_path, index=False)

    print(f"\nSaved to: {output_path}")