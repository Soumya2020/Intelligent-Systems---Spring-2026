from pathlib import Path
import pandas as pd


def prepare_model_data(df):
    df = df.copy()

    print("Original shape:", df.shape)

    # -------------------------
    # Target variable
    # -------------------------
    y = df["loneliness_label"]

    # -------------------------
    # Drop leakage columns
    # -------------------------
    drop_cols = ["participant", "ucla_score", "loneliness_label"]

    # drop q1-q20
    q_cols = [col for col in df.columns if col.startswith("q")]
    drop_cols.extend(q_cols)

    print("\nDropping leakage columns:")
    print(drop_cols)

    X = df.drop(columns=drop_cols)

    print("\nFinal feature shape:", X.shape)
    print("Target shape:", y.shape)

    return X, y


if __name__ == "__main__":
    current_file = Path(__file__).resolve()
    project_root = current_file.parents[2]

    input_path = project_root / "data" / "processed" / "final_multimodal_dataset.csv"

    df = pd.read_csv(input_path)

    X, y = prepare_model_data(df)

    print("\nPreview X:")
    print(X.head())

    print("\nPreview y:")
    print(y.head())

    # Save final model-ready data
    X.to_csv(project_root / "data" / "processed" / "X.csv", index=False)
    y.to_csv(project_root / "data" / "processed" / "y.csv", index=False)

    print("\nSaved X and y")