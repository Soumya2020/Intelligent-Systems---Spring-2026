from pathlib import Path
import pandas as pd
import numpy as np


def get_participant_paths(base_path):
    return sorted([p for p in base_path.iterdir() if p.is_dir()])


def load_csv_if_exists(file_path):
    if file_path.exists():
        return pd.read_csv(file_path)
    return None


def add_datetime_columns(df, timestamp_col="timestamp"):
    df = df.copy()
    df[timestamp_col] = pd.to_numeric(df[timestamp_col], errors="coerce")
    df["datetime"] = pd.to_datetime(df[timestamp_col], unit="ms", errors="coerce")
    df["date"] = df["datetime"].dt.date
    return df


def extract_screen_features(screen_df):
    features = {}

    if screen_df is None or screen_df.empty:
        return features

    screen_df = add_datetime_columns(screen_df)

    features["screen_total_records"] = len(screen_df)
    features["screen_active_days"] = screen_df["date"].nunique()

    if "screen_status" in screen_df.columns:
        status_counts = screen_df["screen_status"].value_counts(dropna=False)

        for status, count in status_counts.items():
            features[f"screen_status_{status}_count"] = count
            features[f"screen_status_{status}_ratio"] = count / len(screen_df)

    return features


def extract_call_features(calls_df):
    features = {}

    if calls_df is None or calls_df.empty:
        return features

    calls_df = add_datetime_columns(calls_df)
    calls_df["dur"] = pd.to_numeric(calls_df["dur"], errors="coerce")

    features["calls_total_records"] = len(calls_df)
    features["calls_active_days"] = calls_df["date"].nunique()
    features["calls_total_duration"] = calls_df["dur"].fillna(0).sum()
    features["calls_mean_duration"] = calls_df["dur"].fillna(0).mean()
    features["calls_zero_duration_count"] = (calls_df["dur"].fillna(0) == 0).sum()

    if "type" in calls_df.columns:
        type_counts = calls_df["type"].value_counts(dropna=False)

        for call_type, count in type_counts.items():
            features[f"calls_type_{call_type}_count"] = count
            features[f"calls_type_{call_type}_ratio"] = count / len(calls_df)

    return features


def extract_battery_features(battery_df):
    features = {}

    if battery_df is None or battery_df.empty:
        return features

    battery_df = add_datetime_columns(battery_df)
    battery_df["battery_charge_start"] = pd.to_numeric(
        battery_df["battery_charge_start"], errors="coerce"
    )
    battery_df["battery_charge_end"] = pd.to_numeric(
        battery_df["battery_charge_end"], errors="coerce"
    )

    battery_df["charge_gain"] = (
        battery_df["battery_charge_end"] - battery_df["battery_charge_start"]
    )

    features["battery_total_records"] = len(battery_df)
    features["battery_active_days"] = battery_df["date"].nunique()
    features["battery_mean_start"] = battery_df["battery_charge_start"].mean()
    features["battery_mean_end"] = battery_df["battery_charge_end"].mean()
    features["battery_mean_gain"] = battery_df["charge_gain"].mean()
    features["battery_max_gain"] = battery_df["charge_gain"].max()
    features["battery_full_charge_count"] = (battery_df["battery_charge_end"] == 100).sum()

    return features


def build_aware_features_for_participant(participant_path):
    aware_path = participant_path / "Aware"

    row = {"participant": participant_path.name}

    if not aware_path.exists():
        return row

    screen_df = load_csv_if_exists(aware_path / "screen.csv")
    calls_df = load_csv_if_exists(aware_path / "calls.csv")
    battery_df = load_csv_if_exists(aware_path / "battery.csv")

    row.update(extract_screen_features(screen_df))
    row.update(extract_call_features(calls_df))
    row.update(extract_battery_features(battery_df))

    return row


def build_aware_feature_dataset(base_path):
    participant_folders = get_participant_paths(base_path)
    rows = []

    for participant_path in participant_folders:
        rows.append(build_aware_features_for_participant(participant_path))

    return pd.DataFrame(rows)


if __name__ == "__main__":
    current_file = Path(__file__).resolve()
    project_root = current_file.parents[2]

    base_path = project_root / "data" / "raw" / "Loneliness_Dataset_Nov10"
    output_path = project_root / "data" / "processed" / "aware_features.csv"

    aware_df = build_aware_feature_dataset(base_path)

    print(aware_df.head())
    print("\nShape:", aware_df.shape)

    aware_df.to_csv(output_path, index=False)
    print(f"\nSaved to: {output_path}")