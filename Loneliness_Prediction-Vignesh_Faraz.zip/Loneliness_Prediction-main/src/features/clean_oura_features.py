from pathlib import Path
import pandas as pd
from sklearn.preprocessing import StandardScaler


def clean_oura_features(df):
    df = df.copy()

    print("Original shape:", df.shape)

    # -------------------------
    # 1. Separate participant column
    # -------------------------
    participant_col = df["participant"]
    feature_df = df.drop(columns=["participant"]).copy()

    # -------------------------
    # 2. Drop columns with too many missing values
    #    Oura is higher-dimensional, so we allow some missingness
    #    but remove very weak columns
    # -------------------------
    missing_ratio = feature_df.isnull().mean()
    cols_to_drop = missing_ratio[missing_ratio > 0.4].index.tolist()

    print("\nDropping columns (too many NaNs > 40%):")
    print(cols_to_drop)

    feature_df = feature_df.drop(columns=cols_to_drop)

    # -------------------------
    # 3. Fill remaining NaNs with 0
    # -------------------------
    feature_df = feature_df.fillna(0)

    # -------------------------
    # 4. Drop constant columns
    # -------------------------
    nunique = feature_df.nunique()
    constant_cols = nunique[nunique <= 1].index.tolist()

    print("\nDropping constant columns:")
    print(constant_cols)

    feature_df = feature_df.drop(columns=constant_cols)

    # -------------------------
    # 5. Remove weak participants
    #    Keep participants with enough non-zero information
    # -------------------------
    non_zero_counts = (feature_df != 0).sum(axis=1)
    min_non_zero_required = int(0.3 * feature_df.shape[1])

    valid_rows = non_zero_counts > min_non_zero_required

    removed_participants = participant_col[~valid_rows].tolist()

    print("\nMinimum non-zero features required:", min_non_zero_required)
    print("Removing weak participants:", len(removed_participants))
    print("Removed participants:", removed_participants)

    participant_col = participant_col[valid_rows].reset_index(drop=True)
    feature_df = feature_df.loc[valid_rows].reset_index(drop=True)

    # -------------------------
    # 6. Scale features
    # -------------------------
    scaler = StandardScaler()
    scaled_values = scaler.fit_transform(feature_df)

    scaled_df = pd.DataFrame(scaled_values, columns=feature_df.columns)

    # -------------------------
    # 7. Add participant back
    # -------------------------
    scaled_df.insert(0, "participant", participant_col)

    print("\nFinal shape:", scaled_df.shape)

    return scaled_df


if __name__ == "__main__":
    current_file = Path(__file__).resolve()
    project_root = current_file.parents[2]

    input_path = project_root / "data" / "processed" / "oura_features.csv"
    output_path = project_root / "data" / "processed" / "oura_features_clean.csv"

    df = pd.read_csv(input_path)

    clean_df = clean_oura_features(df)

    print("\nPreview:")
    print(clean_df.head())

    clean_df.to_csv(output_path, index=False)

    print(f"\nSaved to: {output_path}")