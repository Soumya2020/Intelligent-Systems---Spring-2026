import pandas as pd
from sklearn.feature_selection import SelectKBest, f_classif

# Load final dataset
data_path = r"F:\PythonProject\prjoect4lonely\data\processed\final_dataset.csv"
df = pd.read_csv(data_path)

print("Original dataset shape:", df.shape)

# Drop unwanted columns
drop_cols = ["loneliness_label"]

if "participant" in df.columns:
    drop_cols.append("participant")

if "ucla_score" in df.columns:
    drop_cols.append("ucla_score")

X = df.drop(columns=drop_cols)
y = df["loneliness_label"]

print("X shape before selection:", X.shape)
print("y shape before selection:", y.shape)

# Feature selection
selector = SelectKBest(score_func=f_classif, k=15)
selector.fit(X, y)

selected_features = X.columns[selector.get_support()]
selected_scores = selector.scores_[selector.get_support()]

# Keep actual top 15
X_top15_actual = X[selected_features].copy()
y_top15_actual = y.copy()

print("\nActual top 15 feature names:")
for i, feature in enumerate(selected_features, start=1):
    print(f"{i}. {feature}")

print("\nX_top15_actual shape:", X_top15_actual.shape)
print("y_top15_actual shape:", y_top15_actual.shape)

# Save clean files
X_top15_actual.to_csv(
    r"F:\PythonProject\prjoect4lonely\data\processed\X_top15_actual.csv",
    index=False
)

y_top15_actual.to_csv(
    r"F:\PythonProject\prjoect4lonely\data\processed\y_top15_actual.csv",
    index=False
)

# Save feature scores too
top15_df = pd.DataFrame({
    "feature": selected_features,
    "score": selected_scores
}).sort_values(by="score", ascending=False)

top15_df.to_csv(
    r"F:\PythonProject\prjoect4lonely\data\processed\top15_selected_features.csv",
    index=False
)

print("\nSaved files successfully:")
print("1. X_top15_actual.csv")
print("2. y_top15_actual.csv")
print("3. top15_selected_features.csv")