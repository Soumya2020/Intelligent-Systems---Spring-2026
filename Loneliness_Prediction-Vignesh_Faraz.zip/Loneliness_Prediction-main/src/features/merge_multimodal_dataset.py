from pathlib import Path
import pandas as pd


def merge_multimodal_datasets(aware_path, oura_path, ucla_path):
    # Load datasets
    aware_df = pd.read_csv(aware_path)
    oura_df = pd.read_csv(oura_path)
    ucla_df = pd.read_csv(ucla_path)

    print("Aware shape:", aware_df.shape)
    print("Oura shape:", oura_df.shape)
    print("UCLA shape:", ucla_df.shape)

    # First merge Aware + Oura
    multimodal_df = aware_df.merge(oura_df, on="participant", how="inner")
    print("\nAfter merging Aware + Oura:", multimodal_df.shape)

    # Then merge with UCLA targets
    final_df = multimodal_df.merge(ucla_df, on="participant", how="inner")
    print("After merging with UCLA:", final_df.shape)

    # Label distribution
    print("\nLabel distribution:")
    print(final_df["loneliness_label"].value_counts())

    return final_df


if __name__ == "__main__":
    current_file = Path(__file__).resolve()
    project_root = current_file.parents[2]

    aware_path = project_root / "data" / "processed" / "aware_features_clean.csv"
    oura_path = project_root / "data" / "processed" / "oura_features_clean.csv"
    ucla_path = project_root / "data" / "processed" / "ucla_targets.csv"
    output_path = project_root / "data" / "processed" / "final_multimodal_dataset.csv"

    final_df = merge_multimodal_datasets(aware_path, oura_path, ucla_path)

    print("\nPreview:")
    print(final_df.head())

    final_df.to_csv(output_path, index=False)

    print(f"\nSaved to: {output_path}")