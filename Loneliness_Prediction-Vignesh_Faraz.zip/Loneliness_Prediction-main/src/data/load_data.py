from pathlib import Path
import pandas as pd


def get_participant_paths(base_path):
    return sorted([p for p in base_path.iterdir() if p.is_dir()])


def find_ucla_file(participant_path):
    survey_path = participant_path / "Surveys"

    if not survey_path.exists():
        return None

    for file in survey_path.glob("*UCLA*.csv"):
        return file

    return None


def load_ucla_file(participant_path):
    ucla_file = find_ucla_file(participant_path)

    if ucla_file is None:
        return None

    return pd.read_csv(ucla_file)


def convert_ucla_responses(ucla_df):
    """
    Convert q1-q20 text answers into numeric values.
    """
    score_map = {
        "never": 1,
        "rarely": 2,
        "sometimes": 3,
        "always": 4
    }

    question_cols = [f"q{i}" for i in range(1, 21)]
    scored_df = ucla_df.copy()

    for col in question_cols:
        scored_df[col] = (
            scored_df[col]
            .astype(str)
            .str.strip()
            .str.lower()
            .map(score_map)
        )

    return scored_df


def compute_ucla_score(scored_df):
    question_cols = [f"q{i}" for i in range(1, 21)]
    return scored_df[question_cols].sum(axis=1).iloc[0]


def make_binary_label(total_score, threshold=54):
    """
    0 = low loneliness
    1 = high loneliness
    """
    return 1 if total_score >= threshold else 0


def build_ucla_target_dataset(base_path):
    participant_folders = get_participant_paths(base_path)
    records = []

    question_cols = [f"q{i}" for i in range(1, 21)]

    for participant_path in participant_folders:
        participant_name = participant_path.name
        ucla_df = load_ucla_file(participant_path)

        if ucla_df is None:
            print(f"Skipping {participant_name} (no UCLA file)")
            continue

        scored_df = convert_ucla_responses(ucla_df)
        total_score = compute_ucla_score(scored_df)
        binary_label = make_binary_label(total_score)

        row = {
            "participant": participant_name
        }

        for col in question_cols:
            row[col] = scored_df[col].iloc[0]

        row["ucla_score"] = total_score
        row["loneliness_label"] = binary_label

        records.append(row)

    return pd.DataFrame(records)


if __name__ == "__main__":
    current_file = Path(__file__).resolve()
    project_root = current_file.parents[2]

    base_path = project_root / "data" / "raw" / "Loneliness_Dataset_Nov10"
    output_path = project_root / "data" / "processed" / "ucla_targets.csv"

    target_df = build_ucla_target_dataset(base_path)

    print(target_df.head())
    print("\nLabel counts:")
    print(target_df["loneliness_label"].value_counts())

    target_df.to_csv(output_path, index=False)
    print(f"\nSaved to: {output_path}")