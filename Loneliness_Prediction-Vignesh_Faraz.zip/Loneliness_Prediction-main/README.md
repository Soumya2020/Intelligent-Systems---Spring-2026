# Multimodal Loneliness Prediction using Behavioral Data

## Overview

This project explores how loneliness can be predicted using everyday behavioral data collected from smartphones and wearable devices.

Instead of relying only on surveys, which are usually taken once and don’t capture day-to-day changes, this approach uses passive data like screen usage, sleep patterns, and activity levels.

The idea is simple: our daily behavior reflects how we feel. By analyzing these patterns over time, we can build a machine learning model that identifies whether someone is experiencing high or low levels of loneliness.

---

## Objective

The goal of this project is to build a complete machine learning pipeline that can:

- Predict loneliness as either high or low  
- Use real-world behavioral data instead of only surveys  
- Compare different machine learning models  
- Understand which features actually matter the most  

---

## Dataset Description

The dataset combines information collected over 28 days from two main sources.

### Smartphone Data (Aware)

- Screen usage  
- App activity  
- Call frequency and duration  
- General phone usage behavior  

### Wearable Data (Oura)

- Sleep duration and quality  
- Readiness score  
- Activity levels  
- Sleep stages (REM, disturbances)  

---

## Target Variable

Loneliness is measured using the UCLA Loneliness Scale:

- Scores ≥ 54 → High loneliness  
- Scores < 54 → Low loneliness  

---

## Pipeline

### Data Preprocessing
- Missing value handling  
- Feature cleaning  
- Participant filtering  
- Dataset merging  

### Feature Engineering
- Mean, standard deviation  
- Minimum and maximum aggregation  
- Conversion from temporal → static features  

### Feature Selection
- SelectKBest used to retain top features  

### Models Used
- Logistic Regression  
- Support Vector Machine (SVM)  
- Random Forest  
- XGBoost  

### Evaluation Metrics
- Accuracy  
- Precision  
- Recall  
- F1 Score  
- ROC-AUC  

---

## Results

### Accuracy Comparison
<img src="outputs/figures/accuracy_comparison.png" width="500">

### Precision Comparison
<img src="outputs/figures/precision_comparison.png" width="500">

### Recall Comparison
<img src="outputs/figures/recall_comparison.png" width="500">

### F1 Score Comparison
<img src="outputs/figures/f1_score_comparison.png" width="500">

### ROC-AUC Comparison
<img src="outputs/figures/roc_auc_comparison.png" width="500">

---

## Model Performance Curves

### ROC Curves
<img src="outputs/figures/all_models_roc_curve.png" width="500">

### Precision-Recall Curves
<img src="outputs/figures/all_models_precision_recall_curves.png" width="500">

---

## Confusion Matrices

### Logistic Regression
<img src="outputs/figures/logistic_regression_plus_selectkbest_confusion_matrix.png" width="500">

### SVM
<img src="outputs/figures/svm_plus_selectkbest_confusion_matrix.png" width="500">

### Random Forest
<img src="outputs/figures/random_forest_confusion_matrix.png" width="500">

### XGBoost
<img src="outputs/figures/xgboost_plus_selectkbest_confusion_matrix.png" width="500">

---

## Feature Importance

### Random Forest
<img src="outputs/figures/random_forest_feature_importance.png" width="500">

### XGBoost
<img src="outputs/figures/xgboost_plus_selectkbest_feature_importance.png" width="500">

---

## Combined Metrics Overview
<img src="outputs/figures/all_metrics_grouped.png" width="600">

---

## Research Paper

👉 [View Full Paper](outputs/reports/Predicting%20Loneliness.pdf)

---

## Project Structure
