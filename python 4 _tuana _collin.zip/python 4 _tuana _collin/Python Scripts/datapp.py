"""
Data Preprocessing Pipeline for "Loneliness and Well-being in Finnish Immigrants" Dataset
OPTIMIZED VERSION - Fast CSV processing with parallel execution and fixed date merging
"""

import pandas as pd
import numpy as np
import os
from pathlib import Path
from datetime import datetime, timedelta
import glob
import warnings
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
import multiprocessing as mp
from functools import partial
import time

warnings.filterwarnings('ignore')

class LonelinessDataPreprocessor:
    """
    Optimized Preprocessor for the Finnish Immigrants Loneliness Study dataset
    Handles AWARE smartphone data, Oura Ring data, Watch sensor data, and Survey/EMA data
    """
    
    def __init__(self, data_path, output_path=None, n_workers=None):
        """
        Initialize the preprocessor
        
        Parameters:
        -----------
        data_path : str or Path
            Path to the dataset folder containing Participant_* folders
        output_path : str or Path, optional
            Path where processed files will be saved
        n_workers : int, optional
            Number of parallel workers for processing (default: CPU count - 1)
        """
        self.data_path = Path(data_path)
        self.output_path = Path(output_path) if output_path else self.data_path / 'processed'
        self.output_path.mkdir(parents=True, exist_ok=True)
        
        # Set number of workers for parallel processing
        self.n_workers = n_workers or max(1, mp.cpu_count() - 1)
        
        # Cache for parsed timestamps to avoid redundant conversions
        self._timestamp_cache = {}
        
        if not self.data_path.exists():
            raise ValueError(f"Data path does not exist: {self.data_path}")
        
        print(f"Data path: {self.data_path}")
        print(f"Output path: {self.output_path}")
        print(f"Using {self.n_workers} worker processes")
        
    def unix_to_datetime(self, timestamp_ms):
        """
        Convert 13-digit Unix timestamp to datetime with caching
        
        Parameters:
        -----------
        timestamp_ms : int, float, or str
            Unix timestamp in milliseconds
            
        Returns:
        --------
        pandas.Timestamp or NaT
        """
        if pd.isna(timestamp_ms):
            return pd.NaT
        
        # Use cache for repeated timestamps
        cache_key = str(timestamp_ms)
        if cache_key in self._timestamp_cache:
            return self._timestamp_cache[cache_key]
        
        try:
            if isinstance(timestamp_ms, str):
                timestamp_ms = int(timestamp_ms)
            result = pd.to_datetime(timestamp_ms, unit='ms')
            # Cache only if cache isn't too large
            if len(self._timestamp_cache) < 10000:
                self._timestamp_cache[cache_key] = result
            return result
        except:
            return pd.NaT
    
    def _fast_convert_timestamps(self, df, timestamp_col):
        """
        Fast vectorized timestamp conversion
        
        Parameters:
        -----------
        df : pandas.DataFrame
            DataFrame containing timestamp column
        timestamp_col : str
            Name of the timestamp column
            
        Returns:
        --------
        pandas.DataFrame with added 'datetime' column
        """
        if timestamp_col not in df.columns:
            return df
        
        # Vectorized conversion using pandas built-in
        try:
            # Check if column is numeric (Unix timestamps)
            if pd.api.types.is_numeric_dtype(df[timestamp_col]):
                df['datetime'] = pd.to_datetime(df[timestamp_col], unit='ms', errors='coerce')
            else:
                df['datetime'] = pd.to_datetime(df[timestamp_col], errors='coerce')
        except:
            # Fallback to apply if vectorized fails
            df['datetime'] = df[timestamp_col].apply(self.unix_to_datetime)
        
        return df
    
    def _standardize_date_column(self, df):
        """
        Ensure date column is datetime type for consistent merging
        
        Parameters:
        -----------
        df : pandas.DataFrame
            DataFrame with potential date column
            
        Returns:
        --------
        pandas.DataFrame with standardized date column
        """
        if 'date' in df.columns:
            if not pd.api.types.is_datetime64_any_dtype(df['date']):
                df['date'] = pd.to_datetime(df['date'])
        return df
    
    def _merge_dataframes_fast(self, df1, df2, on='date', how='outer'):
        """
        Fast merge with standardized date columns
        
        Parameters:
        -----------
        df1, df2 : pandas.DataFrame
            DataFrames to merge
        on : str
            Column name to merge on
        how : str
            Type of merge (outer, inner, left, right)
            
        Returns:
        --------
        pandas.DataFrame after merging
        """
        df1 = self._standardize_date_column(df1)
        df2 = self._standardize_date_column(df2)
        return pd.merge(df1, df2, on=on, how=how)
    
    def process_screen_data_fast(self, screen_df):
        """
        Optimized screen data processing using vectorized operations
        
        Parameters:
        -----------
        screen_df : pandas.DataFrame
            DataFrame with screen data (timestamp, screen_status)
            
        Returns:
        --------
        pandas.DataFrame with daily screen time
        """
        if screen_df.empty or 'timestamp' not in screen_df.columns or 'screen_status' not in screen_df.columns:
            return pd.DataFrame(columns=['date', 'screen_time_minutes'])
        
        screen_df = screen_df.sort_values('timestamp').copy()
        screen_df = self._fast_convert_timestamps(screen_df, 'timestamp')
        screen_df = screen_df.dropna(subset=['datetime'])
        
        if screen_df.empty:
            return pd.DataFrame(columns=['date', 'screen_time_minutes'])
        
        # Vectorized screen status shift for transition detection
        screen_df['next_status'] = screen_df['screen_status'].shift(-1)
        screen_df['status_changed'] = screen_df['screen_status'] != screen_df['next_status']
        
        # Find screen on events (status 1 followed by status 0)
        screen_on_starts = screen_df[(screen_df['screen_status'] == 1) & 
                                      (screen_df['status_changed'])].copy()
        screen_on_ends = screen_df[(screen_df['screen_status'] == 0) & 
                                    (screen_df['status_changed'])].copy()
        
        # Align start and end times
        min_len = min(len(screen_on_starts), len(screen_on_ends))
        if min_len == 0:
            return pd.DataFrame(columns=['date', 'screen_time_minutes'])
        
        screen_on_starts = screen_on_starts.iloc[:min_len]
        screen_on_ends = screen_on_ends.iloc[:min_len]
        
        # Calculate durations vectorized
        durations = (screen_on_ends['datetime'].values - screen_on_starts['datetime'].values).astype('timedelta64[m]').astype(float)
        durations = durations[(durations > 0) & (durations < 1440)]
        
        if len(durations) == 0:
            return pd.DataFrame(columns=['date', 'screen_time_minutes'])
        
        # Create results dataframe
        results = pd.DataFrame({
            'date': screen_on_starts['datetime'].dt.date.iloc[:len(durations)],
            'duration_minutes': durations
        })
        
        daily_screen_time = results.groupby('date')['duration_minutes'].sum().reset_index()
        daily_screen_time.columns = ['date', 'screen_time_minutes']
        daily_screen_time['date'] = pd.to_datetime(daily_screen_time['date'])
        
        return daily_screen_time
    
    def process_calls_data_fast(self, calls_df):
        """
        Optimized call data processing
        
        Parameters:
        -----------
        calls_df : pandas.DataFrame
            DataFrame with call data (timestamp, type, dur)
            
        Returns:
        --------
        pandas.DataFrame with daily call metrics
        """
        if calls_df.empty:
            return pd.DataFrame(columns=['date', 'total_calls', 'outgoing_calls', 
                                         'incoming_calls', 'missed_calls', 'total_call_duration'])
        
        calls_df = self._fast_convert_timestamps(calls_df, 'timestamp')
        calls_df = calls_df.dropna(subset=['datetime'])
        calls_df['date'] = calls_df['datetime'].dt.date
        
        # Vectorized aggregation
        daily_calls = calls_df.groupby('date').agg(
            total_calls=('type', 'count'),
            total_call_duration=('dur', 'sum')
        ).reset_index()
        
        # Pivot for call types - vectorized
        if 'type' in calls_df.columns:
            type_counts = calls_df.groupby(['date', 'type']).size().unstack(fill_value=0)
            for call_type, name in {1: 'incoming_calls', 2: 'outgoing_calls', 3: 'missed_calls'}.items():
                if call_type in type_counts.columns:
                    daily_calls[name] = type_counts[call_type]
                else:
                    daily_calls[name] = 0
        
        daily_calls['date'] = pd.to_datetime(daily_calls['date'])
        return daily_calls
    
    def process_count_data_fast(self, df, name):
        """
        Fast processing for counting events (messages, notifications)
        
        Parameters:
        -----------
        df : pandas.DataFrame
            DataFrame with timestamp column
        name : str
            Name for the count column
            
        Returns:
        --------
        pandas.DataFrame with daily counts
        """
        if df.empty:
            return pd.DataFrame(columns=['date', f'{name}_count'])
        
        df = self._fast_convert_timestamps(df, 'timestamp')
        df = df.dropna(subset=['datetime'])
        df['date'] = pd.to_datetime(df['datetime'].dt.date)
        
        daily_counts = df.groupby('date').size().reset_index(name=f'{name}_count')
        return daily_counts
    
    def process_oura_data_fast(self, oura_path):
        """
        Optimized Oura Ring data processing - reads all CSVs efficiently
        
        Parameters:
        -----------
        oura_path : Path
            Path to Oura folder for a participant
            
        Returns:
        --------
        pandas.DataFrame with daily Oura metrics
        """
        print(f"    Processing Oura data from {oura_path}")
        
        oura_files = list(oura_path.glob('*.csv'))
        if not oura_files:
            print("    No Oura CSV files found")
            return pd.DataFrame()
        
        daily_metrics = {}
        
        for file in oura_files:
            file_name = file.stem.lower()
            print(f"      Reading {file.name}")
            
            try:
                # Read CSV efficiently
                df = pd.read_csv(file, low_memory=False)
                if df.empty:
                    continue
                
                # Find timestamp column
                timestamp_col = None
                for col in ['timestamp', 'unix_timestamp', 'datetime', 'time', 'day', 'date']:
                    if col in df.columns:
                        timestamp_col = col
                        break
                
                if timestamp_col is None:
                    print(f"      No timestamp column found in {file.name}")
                    print(f"      Columns: {list(df.columns)}")
                    continue
                
                # Vectorized timestamp conversion
                df = self._fast_convert_timestamps(df, timestamp_col)
                df = df.dropna(subset=['datetime'])
                
                if df.empty:
                    continue
                
                df['date'] = pd.to_datetime(df['datetime'].dt.date)
                
                # Process based on file type using vectorized operations
                if 'sleep' in file_name:
                    self._process_sleep_data_fast(df, daily_metrics)
                elif 'activity' in file_name:
                    self._process_activity_data_fast(df, daily_metrics)
                elif 'readiness' in file_name:
                    self._process_readiness_data_fast(df, daily_metrics)
                    
            except Exception as e:
                print(f"      Error processing {file.name}: {e}")
                continue
        
        if not daily_metrics:
            print("    No valid Oura metrics extracted")
            return pd.DataFrame()
        
        # Convert to DataFrame efficiently
        daily_df = pd.DataFrame.from_dict(daily_metrics, orient='index').reset_index()
        if not daily_df.empty:
            daily_df.columns = ['date'] + list(daily_df.columns[1:])
            daily_df['date'] = pd.to_datetime(daily_df['date'])
        
        print(f"    Extracted {len(daily_df)} days of Oura data")
        return daily_df
    
    def _process_sleep_data_fast(self, df, daily_metrics):
        """
        Vectorized sleep data processing
        
        Parameters:
        -----------
        df : pandas.DataFrame
            DataFrame with sleep data
        daily_metrics : dict
            Dictionary to store aggregated metrics
        """
        sleep_cols = {
            'duration_minutes': ['sleep_duration', 'duration', 'total_sleep', 'sleep_total'],
            'deep_minutes': ['sleep_deep', 'deep', 'deep_sleep'],
            'rem_minutes': ['sleep_rem', 'rem', 'rem_sleep'],
            'light_minutes': ['sleep_light', 'light', 'light_sleep'],
            'avg_heart_rate': ['sleep_hr_average', 'hr_average', 'avg_heart_rate'],
            'hrv_rmssd': ['sleep_rmssd', 'rmssd', 'hrv_rmssd'],
            'efficiency': ['sleep_efficiency', 'efficiency'],
            'awake_minutes': ['sleep_awake', 'awake']
        }
        
        for target, possible_cols in sleep_cols.items():
            for col in possible_cols:
                if col in df.columns:
                    # Vectorized extraction
                    for date, value in zip(df['date'], df[col]):
                        if pd.notna(value):
                            if date not in daily_metrics:
                                daily_metrics[date] = {}
                            # Convert seconds to minutes if needed
                            if target.endswith('_minutes') and value > 1000:
                                value = value / 60
                            daily_metrics[date][target] = value
                    break  # Found matching column, move to next target
    
    def _process_activity_data_fast(self, df, daily_metrics):
        """
        Vectorized activity data processing
        
        Parameters:
        -----------
        df : pandas.DataFrame
            DataFrame with activity data
        daily_metrics : dict
            Dictionary to store aggregated metrics
        """
        activity_cols = {
            'steps': ['activity_steps', 'steps', 'total_steps'],
            'active_calories': ['activity_cal_active', 'cal_active', 'active_calories'],
            'total_calories': ['activity_cal_total', 'cal_total', 'total_calories'],
            'inactivity_minutes': ['activity_inactive', 'inactive'],
            'low_activity_minutes': ['activity_low', 'low'],
            'medium_activity_minutes': ['activity_medium', 'medium'],
            'high_activity_minutes': ['activity_high', 'high'],
            'activity_score': ['activity_score', 'score']
        }
        
        for target, possible_cols in activity_cols.items():
            for col in possible_cols:
                if col in df.columns:
                    for date, value in zip(df['date'], df[col]):
                        if pd.notna(value):
                            if date not in daily_metrics:
                                daily_metrics[date] = {}
                            daily_metrics[date][target] = value
                    break
    
    def _process_readiness_data_fast(self, df, daily_metrics):
        """
        Vectorized readiness data processing
        
        Parameters:
        -----------
        df : pandas.DataFrame
            DataFrame with readiness data
        daily_metrics : dict
            Dictionary to store aggregated metrics
        """
        readiness_cols = {
            'readiness_score': ['readiness_score', 'score'],
            'hrv_balance': ['readiness_score_hrv_balance', 'hrv_balance'],
            'resting_hr': ['readiness_score_resting_hr', 'resting_hr'],
            'sleep_balance': ['readiness_score_sleep_balance', 'sleep_balance'],
            'activity_balance': ['readiness_score_activity_balance', 'activity_balance']
        }
        
        for target, possible_cols in readiness_cols.items():
            for col in possible_cols:
                if col in df.columns:
                    for date, value in zip(df['date'], df[col]):
                        if pd.notna(value):
                            if date not in daily_metrics:
                                daily_metrics[date] = {}
                            daily_metrics[date][target] = value
                    break
    
    def process_watch_data_fast(self, watch_path):
        """
        Optimized Samsung Watch data processing
        
        Parameters:
        -----------
        watch_path : Path
            Path to Watch folder for a participant
            
        Returns:
        --------
        pandas.DataFrame with daily Watch metrics
        """
        print(f"    Processing Watch data from {watch_path}")
        
        watch_files = list(watch_path.glob('*.csv'))
        if not watch_files:
            print("    No Watch CSV files found")
            return pd.DataFrame()
        
        daily_watch_metrics = {}
        
        for file in watch_files:
            try:
                # Read only necessary columns for speed
                cols_to_read = ['timestamp']
                if 'ppg' in str(file).lower():
                    cols_to_read.extend(['ppg', 'hrm'])
                else:
                    cols_to_read.extend(['hrm', 'accx', 'accy', 'accz', 'gyrx', 'gyry', 'gyrz', 'pressure'])
                
                # Only read columns that exist in the file
                try:
                    df = pd.read_csv(file, usecols=[c for c in cols_to_read if c in pd.read_csv(file, nrows=1).columns])
                except:
                    df = pd.read_csv(file, low_memory=False)
                
                if df.empty:
                    continue
                
                df = self._fast_convert_timestamps(df, 'timestamp')
                df = df.dropna(subset=['datetime'])
                df['date'] = pd.to_datetime(df['datetime'].dt.date)
                
                # Process each date
                for date in df['date'].unique():
                    date_data = df[df['date'] == date]
                    
                    if date not in daily_watch_metrics:
                        daily_watch_metrics[date] = {}
                    
                    # Heart rate data
                    if 'hrm' in date_data.columns:
                        hr_data = date_data['hrm'].dropna()
                        if not hr_data.empty:
                            daily_watch_metrics[date]['watch_avg_heart_rate'] = hr_data.mean()
                            daily_watch_metrics[date]['watch_min_heart_rate'] = hr_data.min()
                            daily_watch_metrics[date]['watch_max_heart_rate'] = hr_data.max()
                    
                    # PPG signal
                    if 'ppg' in date_data.columns:
                        ppg_data = date_data['ppg'].dropna()
                        if not ppg_data.empty:
                            daily_watch_metrics[date]['avg_ppg_amplitude'] = ppg_data.std()
                            if ppg_data.mean() > 0:
                                daily_watch_metrics[date]['ppg_variability'] = ppg_data.std() / ppg_data.mean()
                    
                    # Accelerometer data
                    if all(col in date_data.columns for col in ['accx', 'accy', 'accz']):
                        acc_magnitude = np.sqrt(
                            date_data['accx'].fillna(0)**2 + 
                            date_data['accy'].fillna(0)**2 + 
                            date_data['accz'].fillna(0)**2
                        )
                        daily_watch_metrics[date]['avg_acceleration'] = acc_magnitude.mean()
                        daily_watch_metrics[date]['watch_activity_level'] = (acc_magnitude > 1.5).mean()
                    
                    # Gyroscope data
                    if all(col in date_data.columns for col in ['gyrx', 'gyry', 'gyrz']):
                        gyro_magnitude = np.sqrt(
                            date_data['gyrx'].fillna(0)**2 + 
                            date_data['gyry'].fillna(0)**2 + 
                            date_data['gyrz'].fillna(0)**2
                        )
                        daily_watch_metrics[date]['avg_gyroscope'] = gyro_magnitude.mean()
                    
                    # Pressure data
                    if 'pressure' in date_data.columns:
                        pressure_data = date_data['pressure'].dropna()
                        if not pressure_data.empty:
                            daily_watch_metrics[date]['avg_pressure'] = pressure_data.mean()
                            daily_watch_metrics[date]['pressure_variability'] = pressure_data.std()
                            
            except Exception as e:
                continue
        
        if not daily_watch_metrics:
            return pd.DataFrame()
        
        watch_df = pd.DataFrame.from_dict(daily_watch_metrics, orient='index').reset_index()
        watch_df.columns = ['date'] + list(watch_df.columns[1:])
        watch_df['date'] = pd.to_datetime(watch_df['date'])
        
        print(f"    Extracted {len(watch_df)} days of Watch data")
        return watch_df
    
    def process_ema_data_fast(self, survey_path):
        """
        Optimized EMA data processing
        
        Parameters:
        -----------
        survey_path : Path
            Path to Survey folder for a participant
            
        Returns:
        --------
        pandas.DataFrame with daily EMA metrics
        """
        ema_files = list(survey_path.glob('*ema*.csv')) + list(survey_path.glob('*EMA*.csv'))
        
        if not ema_files:
            return pd.DataFrame()
        
        try:
            ema_df = pd.read_csv(ema_files[0])
            if ema_df.empty:
                return pd.DataFrame()
            
            # Find timestamp column
            timestamp_col = None
            for col in ['timestamp', 'unix_timestamp', 'datetime', 'time']:
                if col in ema_df.columns:
                    timestamp_col = col
                    break
            
            if timestamp_col is None:
                return pd.DataFrame()
            
            ema_df = self._fast_convert_timestamps(ema_df, timestamp_col)
            ema_df = ema_df.dropna(subset=['datetime'])
            ema_df['date'] = pd.to_datetime(ema_df['datetime'].dt.date)
            
            # Look for columns with relevant keywords
            loneliness_cols = [col for col in ema_df.columns if 'loneliness' in col.lower()]
            stress_cols = [col for col in ema_df.columns if 'stress' in col.lower()]
            mood_cols = [col for col in ema_df.columns if 'mood' in col.lower() or 'affect' in col.lower()]
            
            # If no specific columns, look for numeric columns (Likert scales)
            if not loneliness_cols and not stress_cols and not mood_cols:
                numeric_cols = ema_df.select_dtypes(include=[np.number]).columns.tolist()
                numeric_cols = [col for col in numeric_cols if col not in [timestamp_col, 'datetime']]
                
                if len(numeric_cols) >= 3:
                    loneliness_cols = [numeric_cols[0]] if len(numeric_cols) > 0 else []
                    stress_cols = [numeric_cols[1]] if len(numeric_cols) > 1 else []
                    mood_cols = [numeric_cols[2]] if len(numeric_cols) > 2 else []
            
            # Aggregate daily
            agg_dict = {}
            if loneliness_cols:
                agg_dict[loneliness_cols[0]] = 'mean'
            if stress_cols:
                agg_dict[stress_cols[0]] = 'mean'
            if mood_cols:
                agg_dict[mood_cols[0]] = 'mean'
            
            if agg_dict:
                daily_ema = ema_df.groupby('date').agg(agg_dict).reset_index()
                col_mapping = {}
                if loneliness_cols:
                    col_mapping[loneliness_cols[0]] = 'daily_loneliness_avg'
                if stress_cols:
                    col_mapping[stress_cols[0]] = 'daily_stress_avg'
                if mood_cols:
                    col_mapping[mood_cols[0]] = 'daily_mood_avg'
                
                daily_ema = daily_ema.rename(columns=col_mapping)
                daily_ema['date'] = pd.to_datetime(daily_ema['date'])
                print(f"    Extracted {len(daily_ema)} days of EMA data")
                return daily_ema
            
            return pd.DataFrame()
            
        except Exception as e:
            print(f"    Error processing EMA data: {e}")
            return pd.DataFrame()
    
    def process_participant_fast(self, participant_path):
        """
        Process all data for a single participant with optimizations
        
        Parameters:
        -----------
        participant_path : Path
            Path to participant folder (e.g., Participant_1)
            
        Returns:
        --------
        pandas.DataFrame with all daily metrics for the participant
        """
        participant_id = participant_path.name
        print(f"\n{'='*60}")
        print(f"Processing participant: {participant_id}")
        print(f"{'='*60}")
        
        daily_data = {}
        
        # Define paths
        aware_path = participant_path / 'Aware'
        oura_path = participant_path / 'Oura'
        watch_path = participant_path / 'Watch'
        survey_path = participant_path / 'Survey'
        
        # Process AWARE data
        if aware_path.exists():
            print(f"\n  AWARE data found:")
            
            # Screen data
            screen_file = aware_path / 'screen.csv'
            if screen_file.exists():
                screen_df = pd.read_csv(screen_file)
                daily_screen = self.process_screen_data_fast(screen_df)
                if not daily_screen.empty:
                    daily_data['screen'] = daily_screen
                    print(f"    - Screen: {len(daily_screen)} days")
            
            # Notifications
            notifications_file = aware_path / 'notifications.csv'
            if notifications_file.exists():
                notifications_df = pd.read_csv(notifications_file)
                daily_notifications = self.process_count_data_fast(notifications_df, 'notification')
                if not daily_notifications.empty:
                    daily_data['notifications'] = daily_notifications
                    print(f"    - Notifications: {len(daily_notifications)} days")
            
            # Calls
            calls_file = aware_path / 'calls.csv'
            if calls_file.exists():
                calls_df = pd.read_csv(calls_file)
                daily_calls = self.process_calls_data_fast(calls_df)
                if not daily_calls.empty:
                    daily_data['calls'] = daily_calls
                    print(f"    - Calls: {len(daily_calls)} days")
            
            # Messages
            messages_file = aware_path / 'messages.csv'
            if messages_file.exists():
                messages_df = pd.read_csv(messages_file)
                daily_messages = self.process_count_data_fast(messages_df, 'message')
                if not daily_messages.empty:
                    daily_data['messages'] = daily_messages
                    print(f"    - Messages: {len(daily_messages)} days")
        
        # Process Oura data
        if oura_path.exists():
            print(f"\n  Oura data found:")
            daily_oura = self.process_oura_data_fast(oura_path)
            if not daily_oura.empty:
                daily_data['oura'] = daily_oura
                print(f"    - Oura: {len(daily_oura)} days")
        else:
            print(f"\n  No Oura folder found")
        
        # Process Watch data
        if watch_path.exists():
            print(f"\n  Watch data found:")
            daily_watch = self.process_watch_data_fast(watch_path)
            if not daily_watch.empty:
                daily_data['watch'] = daily_watch
                print(f"    - Watch: {len(daily_watch)} days")
        else:
            print(f"\n  No Watch folder found")
        
        # Process Survey/EMA data
        if survey_path.exists():
            print(f"\n  Survey data found:")
            daily_ema = self.process_ema_data_fast(survey_path)
            if not daily_ema.empty:
                daily_data['ema'] = daily_ema
                print(f"    - EMA: {len(daily_ema)} days")
        
        # Merge all daily data
        if not daily_data:
            print(f"\n  No data found for {participant_id}")
            return pd.DataFrame()
        
        # Start with the first dataframe and merge using the safe merge function
        merged_data = list(daily_data.values())[0]
        
        # Merge with remaining dataframes
        for key, df in list(daily_data.items())[1:]:
            merged_data = self._merge_dataframes_fast(merged_data, df, on='date', how='outer')
        
        # Add participant ID
        merged_data['participant_id'] = participant_id
        
        # Sort by date
        merged_data = merged_data.sort_values('date')
        merged_data['date'] = pd.to_datetime(merged_data['date'])
        
        # Add study day
        if not merged_data.empty:
            min_date = merged_data['date'].min()
            merged_data['study_day'] = (merged_data['date'] - min_date).dt.days + 1
        
        print(f"\n  Total: {len(merged_data)} days of merged data")
        
        return merged_data
    
    @staticmethod
    def _process_participant_wrapper(preprocessor, participant_path):
        """
        Wrapper for parallel processing
        
        Parameters:
        -----------
        preprocessor : LonelinessDataPreprocessor
            Preprocessor instance
        participant_path : Path
            Path to participant folder
            
        Returns:
        --------
        pandas.DataFrame with processed data
        """
        try:
            return preprocessor.process_participant_fast(participant_path)
        except Exception as e:
            print(f"Error processing {participant_path.name}: {e}")
            import traceback
            traceback.print_exc()
            return pd.DataFrame()
    
    def run_pipeline_parallel(self, participants=None):
        """
        Run the complete preprocessing pipeline in parallel for faster execution
        
        Parameters:
        -----------
        participants : list, optional
            List of specific participant folder names to process
            
        Returns:
        --------
        pandas.DataFrame with all processed data
        """
        participant_folders = [p for p in self.data_path.iterdir() 
                               if p.is_dir() and p.name.startswith('Participant_')]
        
        if participants:
            participant_folders = [p for p in participant_folders 
                                  if p.name in participants]
        
        print(f"\nFound {len(participant_folders)} participants")
        print(f"Processing in parallel with {self.n_workers} workers...")
        
        start_time = time.time()
        
        # Use ProcessPoolExecutor for parallel processing
        with ProcessPoolExecutor(max_workers=self.n_workers) as executor:
            # Create a partial function with the preprocessor method
            process_func = partial(self._process_participant_wrapper, self)
            
            # Submit all tasks
            futures = [executor.submit(process_func, participant_path) 
                      for participant_path in participant_folders]
            
            # Collect results
            all_data = []
            for future in futures:
                try:
                    result = future.result(timeout=600)  # 10 minute timeout per participant
                    if result is not None and not result.empty:
                        all_data.append(result)
                except Exception as e:
                    print(f"Error in parallel processing: {e}")
        
        elapsed_time = time.time() - start_time
        
        if all_data:
            combined_data = pd.concat(all_data, ignore_index=True)
            
            # Save to CSV
            output_file = self.output_path / 'preprocessed_daily_data.csv'
            combined_data.to_csv(output_file, index=False)
            
            print(f"\n{'='*60}")
            print(f"Processing completed in {elapsed_time:.2f} seconds")
            print(f"Saved combined data to {output_file}")
            
            # Generate summary
            self._generate_summary(combined_data)
            
            return combined_data
        
        print("\nNo data processed")
        return pd.DataFrame()
    
    def _generate_summary(self, data):
        """
        Generate and save data summary
        
        Parameters:
        -----------
        data : pandas.DataFrame
            Processed data
        """
        summary_file = self.output_path / 'data_summary.txt'
        with open(summary_file, 'w') as f:
            f.write("Data Preprocessing Summary\n")
            f.write("=" * 50 + "\n\n")
            f.write(f"Total participants: {len(data['participant_id'].unique())}\n")
            f.write(f"Total days of data: {len(data)}\n")
            f.write(f"Date range: {data['date'].min()} to {data['date'].max()}\n\n")
            f.write("Features Created:\n")
            f.write("-" * 30 + "\n")
            for col in data.columns:
                if col not in ['participant_id', 'date', 'study_day']:
                    non_null = data[col].notna().sum()
                    f.write(f"  {col}: {non_null} non-null values ({non_null/len(data)*100:.1f}%)\n")
        
        print(f"Saved summary to {summary_file}")
        
        # Print feature summary
        print(f"\nFeatures Created:")
        for col in data.columns:
            if col not in ['participant_id', 'date', 'study_day']:
                non_null = data[col].notna().sum()
                print(f"  - {col}: {non_null}/{len(data)} ({non_null/len(data)*100:.1f}%)")
    
    def run_pipeline_sequential(self, participants=None):
        """
        Run the pipeline sequentially (for debugging or when parallel causes issues)
        
        Parameters:
        -----------
        participants : list, optional
            List of specific participant folder names to process
            
        Returns:
        --------
        pandas.DataFrame with all processed data
        """
        participant_folders = [p for p in self.data_path.iterdir() 
                               if p.is_dir() and p.name.startswith('Participant_')]
        
        if participants:
            participant_folders = [p for p in participant_folders 
                                  if p.name in participants]
        
        print(f"\nFound {len(participant_folders)} participants")
        print("Processing sequentially...")
        
        start_time = time.time()
        
        all_data = []
        for participant_path in participant_folders:
            try:
                participant_data = self.process_participant_fast(participant_path)
                if not participant_data.empty:
                    all_data.append(participant_data)
            except Exception as e:
                print(f"\n  ERROR processing {participant_path.name}: {e}")
                import traceback
                traceback.print_exc()
        
        elapsed_time = time.time() - start_time
        
        if all_data:
            combined_data = pd.concat(all_data, ignore_index=True)
            
            # Save to CSV
            output_file = self.output_path / 'preprocessed_daily_data.csv'
            combined_data.to_csv(output_file, index=False)
            
            print(f"\n{'='*60}")
            print(f"Processing completed in {elapsed_time:.2f} seconds")
            print(f"Saved combined data to {output_file}")
            
            self._generate_summary(combined_data)
            
            return combined_data
        
        print("\nNo data processed")
        return pd.DataFrame()
    
    def impute_missing_values(self, data, method='mean'):
        """
        Impute missing values in the processed dataset
        
        Parameters:
        -----------
        data : pandas.DataFrame
            Processed data
        method : str
            Imputation method ('mean', 'median', 'forward_fill')
            
        Returns:
        --------
        pandas.DataFrame with imputed values
        """
        data_imputed = data.copy()
        
        numeric_cols = data_imputed.select_dtypes(include=[np.number]).columns.tolist()
        exclude_cols = ['participant_id', 'study_day']
        numeric_cols = [col for col in numeric_cols if col not in exclude_cols]
        
        if method == 'mean':
            data_imputed[numeric_cols] = data_imputed[numeric_cols].fillna(
                data_imputed.groupby('participant_id')[numeric_cols].transform('mean')
            )
        elif method == 'median':
            data_imputed[numeric_cols] = data_imputed[numeric_cols].fillna(
                data_imputed.groupby('participant_id')[numeric_cols].transform('median')
            )
        elif method == 'forward_fill':
            data_imputed[numeric_cols] = data_imputed.groupby('participant_id')[numeric_cols].fillna(method='ffill')
        
        output_file = self.output_path / f'preprocessed_daily_data_imputed_{method}.csv'
        data_imputed.to_csv(output_file, index=False)
        
        return data_imputed


# ============================================================================
# MAIN EXECUTION
# ============================================================================

if __name__ == "__main__":
    DATA_PATH = "/Users/tuanaturhan/Desktop/Project 4/doi_10_5061_dryad_qz612jmrn__v20251128/Loneliness_Dataset_Nov10"
    OUTPUT_PATH = "/Users/tuanaturhan/Desktop/Project 4/processed_output"
    
    print("=" * 80)
    print("LONELINESS DATASET PREPROCESSING PIPELINE (OPTIMIZED)")
    print("=" * 80)
    
    if not os.path.exists(DATA_PATH):
        print(f"\nERROR: Data path does not exist: {DATA_PATH}")
        exit(1)
    
    # Initialize with parallel processing
    preprocessor = LonelinessDataPreprocessor(DATA_PATH, OUTPUT_PATH, n_workers=4)
    
    # Run pipeline with parallel processing (or use run_pipeline_sequential for debugging)
    processed_data = preprocessor.run_pipeline_parallel()
    
    if processed_data is not None and not processed_data.empty:
        print("\n" + "=" * 80)
        print("PROCESSING COMPLETE")
        print("=" * 80)
        print(f"\nFinal shape: {processed_data.shape}")
        print(f"Participants: {processed_data['participant_id'].nunique()}")
        
        # Optional: Impute missing values
        # imputed_data = preprocessor.impute_missing_values(processed_data, method='mean')
