import pandas as pd
import os


DATA_PATH = "/Users/tuanaturhan/Desktop/Project 4/doi_10_5061_dryad_qz612jmrn__v20251128/Loneliness_Dataset_Nov10"
OUTPUT_PATH = "/Users/tuanaturhan/Desktop/Project 4/processed_output/labels.csv"

# UCLA mapping
mapping = {
    "Rarely": 1,
    "Sometimes": 2,
    "Always": 3
}

all_labels = []

for participant in os.listdir(DATA_PATH):
    if not participant.startswith("Participant_"):
        continue

    survey_path = os.path.join(DATA_PATH, participant, "Surveys")

    if not os.path.exists(survey_path):
        continue

    # found UCLA survey
    for file in os.listdir(survey_path):
        if "UCLA" in file:
            file_path = os.path.join(survey_path, file)

            try:
                df = pd.read_csv(file_path)

                # 20 question columns
                question_cols = [f"q{i}" for i in range(1, 21)]

                # mapping
                for col in question_cols:
                    if col in df.columns:
                        df[col] = df[col].map(mapping)

                # score calculation
                df["UCLA_score"] = df[question_cols].sum(axis=1)

                # create label
                df["label"] = (df["UCLA_score"] > 40).astype(int)

                df["participant_id"] = participant

                all_labels.append(df[["participant_id", "UCLA_score", "label"]])

                print(f"Processed {participant}")

            except Exception as e:
                print(f"Error in {participant}: {e}")

labels_df = pd.concat(all_labels)

labels_df = labels_df.drop_duplicates(subset=["participant_id"])

labels_df.to_csv(OUTPUT_PATH, index=False)

print("\nLABEL CREATION COMPLETE")
print(labels_df.head())
print(f"\nSaved to: {OUTPUT_PATH}")