import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report, roc_auc_score

from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC

# LOAD DATA
daily_df = pd.read_csv("processed_output/preprocessed_daily_data.csv")
labels_df = pd.read_csv("processed_output/labels.csv")

# merge
daily_df['participant_id'] = daily_df['participant_id'].str.strip()
labels_df['participant_id'] = labels_df['participant_id'].str.strip()
df = daily_df.merge(labels_df, on="participant_id")

print("Daily shape:", daily_df.shape)
print("Labels shape:", labels_df.shape)
print("Merged shape:", df.shape)

# drop unnecessary columns
df = df.drop(columns=["incoming_calls", "outgoing_calls"], errors='ignore')

# fill missing values
df = df.fillna(df.mean(numeric_only=True))

# features and target
X = df.drop(columns=["participant_id", "date", "label", "UCLA_score"])
y = df["label"]

print("Feature columns:")
print(X.columns)

# train/test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# scale data (for NN and SVM)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# DEFINE NEURAL NETWORK
model = keras.Sequential([
    layers.Dense(64, activation='relu', input_shape=(X_train.shape[1],)),
    layers.Dense(32, activation='relu'),
    layers.Dense(1, activation='sigmoid')
])

print("\n--- Model Summary ---")
model.summary()

# COMPILE MODEL
optimizer = keras.optimizers.Adam(learning_rate=0.001)

model.compile(
    optimizer=optimizer,
    loss='binary_crossentropy',
    metrics=['accuracy']
)

print("\nOptimizer: Adam")
print("Loss: binary_crossentropy")
print("Learning rate: 0.001")

# TRAIN MODEL
print("\n--- Training Model ---")

history = model.fit(
    X_train_scaled, y_train,
    epochs=10,
    batch_size=32,
    verbose=1
)

# plot training loss
plt.figure(figsize=(4,3))
plt.plot(history.history['loss'])
plt.title('Training Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.grid(True)
plt.show()

# EVALUATE NN
loss, accuracy = model.evaluate(X_test_scaled, y_test, verbose=0)
print(f"\nNeural Network Accuracy: {accuracy:.4f}")

# predictions
print("Predicting...")
y_pred = (model.predict(X_test_scaled) > 0.5).astype(int)

print("\nNeural Network Report:")
print(classification_report(y_test, y_pred))

# ROC-AUC for NN
y_prob = model.predict(X_test_scaled)
roc_auc = roc_auc_score(y_test, y_prob)
print(f"Neural Network ROC-AUC: {roc_auc:.4f}")


# =========================
# OTHER MODELS
# =========================

print("\n--- Other Models ---")

# Random Forest
rf_model = RandomForestClassifier(random_state=42)
rf_model.fit(X_train, y_train)

rf_pred = rf_model.predict(X_test)
print("\nRandom Forest Report:")
print(classification_report(y_test, rf_pred))

rf_acc = rf_model.score(X_test, y_test)
print(f"Random Forest Accuracy: {rf_acc:.4f}")

rf_prob = rf_model.predict_proba(X_test)[:, 1]
print(f"Random Forest ROC-AUC: {roc_auc_score(y_test, rf_prob):.4f}")


# SVM
svm_model = SVC(probability=True)
svm_model.fit(X_train_scaled, y_train)

svm_pred = svm_model.predict(X_test_scaled)
print("\nSVM Report:")
print(classification_report(y_test, svm_pred))

svm_acc = svm_model.score(X_test_scaled, y_test)
print(f"SVM Accuracy: {svm_acc:.4f}")

svm_prob = svm_model.predict_proba(X_test_scaled)[:, 1]
print(f"SVM ROC-AUC: {roc_auc_score(y_test, svm_prob):.4f}")


# XGBoost (optional)
try:
    from xgboost import XGBClassifier

    xgb_model = XGBClassifier(use_label_encoder=False, eval_metric='logloss')
    xgb_model.fit(X_train, y_train)

    xgb_pred = xgb_model.predict(X_test)
    print("\nXGBoost Report:")
    print(classification_report(y_test, xgb_pred))

    xgb_acc = xgb_model.score(X_test, y_test)
    print(f"XGBoost Accuracy: {xgb_acc:.4f}")

    xgb_prob = xgb_model.predict_proba(X_test)[:, 1]
    print(f"XGBoost ROC-AUC: {roc_auc_score(y_test, xgb_prob):.4f}")

except ImportError:
    print("\nXGBoost not installed. Skipping...")